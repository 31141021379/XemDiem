﻿using System.Net;
using System.Windows.Forms;

namespace WinForm
{
#pragma warning disable S110 // Inheritance tree of classes should not be too deep

    public partial class Form1 : Form
#pragma warning restore S110 // Inheritance tree of classes should not be too deep
    {
        private readonly string URL = "http://online.ueh.edu.vn/Portlets/UIS_MySpace/Student/marks/view.aspx?studentid=";

        public Form1()
        {
            InitializeComponent();
        }

        private void LoadResult(string mssv)
        {
            if (string.IsNullOrWhiteSpace(mssv.Trim()))
            {
                MessageBox.Show("Vui lòng nhập MSSV");
            }
            else
            {
                try
                {
                    var HTML = "";
                    using (var wc = new WebClient())
                    {
                        HTML = wc.DownloadString(URL + mssv);
                    }

                    var doc = new HtmlAgilityPack.HtmlDocument();
                    doc.LoadHtml(HTML);

                    var kq = doc.GetElementbyId("Label6").InnerText;
                    var index = kq.IndexOf(':');
                    var point = kq.Substring(index + 2, 4);
                    lblResult.Text = "Sinh viên " + textBox1.Text + ": " + point;
                }
                catch (System.Exception)
                {
                    MessageBox.Show("Có lỗi xảy ra");
                }
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                LoadResult(textBox1.Text.Trim());
            }
        }

        private void btnTang_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Vui lòng nhập URL trước");
            }
            else
            {
                var mssvMoi = double.Parse(textBox1.Text);
                mssvMoi++;
                textBox1.Text = mssvMoi.ToString();
                LoadResult(mssvMoi.ToString());
            }
        }

        private void btnGiam_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Vui lòng nhập URL trước");
            }
            else
            {
                var mssvMoi = double.Parse(textBox1.Text);
                mssvMoi--;
                textBox1.Text = mssvMoi.ToString();
                LoadResult(mssvMoi.ToString());
            }
        }
    }
}